<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>SewaCAMERA</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>

    
      <div class="container-fluid">
        <div class="navbar-header">
          
        </div>
        <div class="collapse navbar-collapse">


        <div class="nav navbar-nav navbar-right">
         <ul id="nav">
          <li ><a href="index.php" style="color:#fff;"><span class="glyphicon glyphicon-home"> Home | </span></a></li>
          <li class="a"><a href="login.php" style="color:#fff;"><span class="glyphicon glyphicon-log-in"> Login</span></a></li>
          </ul>
          <div class="clear"></div>
          
          </div>
      </div>
    </nav>
    <div class="jumbotron">
      <div class="row">
      <div class="col-md-4" style="margin:30px;">
     <img src="img/mir.jpg" width="500px">   
    </div>
      <div class="col-md-6" style="margin-left:70px; margin-top: 80px;">
        <h2><b>Selamat datang di House Camera.<h1 style="color:#f97b61;">Sewa<b>CAMERA.mir</b></h1></h2>
        <p>disini anda bisa menyewa camera dengan mudah, anda tinggal klik, maka camera yang anda inginkan bisa anda sewa. tidak perlu lagi jauh-jauh pergi ke tempat persewaan camera.</p>
      </div>
    </div>
    </div>
    <div style="margin-top:-30px;width:100%,height:50px;text-align:center;background:#d74b35;color:#fff;line-height:60px;font-size:20px;margin-bottom:20px;">
Cara Sewa
</div>
      <div class="jumbotron" style="margin-top:-30px;">
      <div class="row" style="margin:20px;">
		<p><h3><b>1. pilih terlebih dahulu camera yang akan disewa.<br>
		  2. setelah itu mengisi data customer.<br>
          2. Pembayaran dapat dilakukan melalui transfer ke Rekening. Melalui	Konfirmasi Pembayaran.<br>
          3. Setelah melakukan pembayaran, konfirmasi pembayaran dikirim ke-<br>
          <br>
		<p style="color:#0000ff;">Miranda Dewantari,
		BRI Britama,
		No Rek 00497589</p>
		<br>
          4. Selanjutnya camera yang telah disewa dapat diambil di tempat kami.<br><br></b></p>
		<p style="color:red;">* Jika pengembalian lebih dari tanggal penyewaan maka akan dikenakan denda.</p></h3>
    </div>
    </div>
   <div class="footer" style="width:100%;height:270px;color:#fff;background:#d74b35;">
      <div class="row" style="background:#7e7c78;">
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
        <ul>
          <li style="color:#f97b61"><h3><b>Tentang houseCAMERA</b></h3></li>
        </ul></center>
          <hr>
        <ul>
          <li><b>houseCAMERA</b> adalah</li>
          <li>Sebuah tempat penyewaan camera online</li>
          <li>yang menyediakan semua</li>
          <li>jenis camera.</li>
        </ul>
      </div>
      </div>
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
        <ul>
          <li style="color:#f97b61"><h3><b>Alamat Kami</b></h3></li>
        </ul></center>
          <hr>
    
          <ul>
          <li>Jl.Irawan</li>
          <li>Semarang Tengah, Semarang</li>
          <li>Jawa Tengah, Indonesia</li>
          <li></li>
        </ul>
      
      </div>
      </div>
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
        <ul>
          <li style="color:#f97b61"><h3><b>Contact Us</b></h3></li>
          <hr>
         <div class="row">
          <div class="col-md-4">
          <a href="www.messeger.com"><img src="images/copy.png" style="width:70px;height:75px;  "></a>
          </div>
          <div class="col-md-4">
          <a href="www.line.com"><img src="images/lin.jpg" style="width:70px;height:75px;"></a>
          </div>
          <div class="col-md-4">
          <a href=""><img src="images/master.jpg" style="width:75px;height:75px;"></a>
          </div>
         </div>
        </ul>
        </center>
      </div>
      </div>
      </div>
        <div class="copyright" style="line-height:50px;">
        <center>&copy; 2017 Miranda Dewantari.</center>
        </div>
      </div>
  </body>
</html>
