<link href="../../css/bootstrap.min.css" rel="stylesheet">
<?php
include"../../config.php";
$e=$_GET['id'];
$edit=mysql_query("SELECT * FROM buku WHERE id_buku='$e'");
$book = mysql_fetch_array($edit);
?>
<div style="margin-top:30px;width:100%,height:50px;text-align:center;background:#0000ff;color:#fff;line-height:60px;font-size:20px;margin-bottom:20px;">
Edit Camera
</div>
<form action="e_book.php" method="post" enctype="multipart/form-data">
 		<input type="hidden" name="id_buku" class="form-control" value =" <?php  echo $book['id_buku'];?>">
 		
 		</select><br>
 		<b>nama camera :</b> <input type="text" name="nama" class="form-control" value =" <?php  echo $book['nama'];?>" ><br>
 		<b>kode camera :</b><input type="text" name="kode" class="form-control" value =" <?php  echo $book['kode'];?>"><br>
 		<b>jenis camera : </b><input type="text" name="jenis" class="form-control" value =" <?php  echo $book['jenis'];?>"><br>
 		<b>Gambar camera : </b><input type="file" name="gambar" class="form-control" value =" <?php  echo $book['gambar'];?>" ><br>
 		<b>Harga camera : </b><input type="text" name="harga" class="form-control" value =" <?php  echo $book['harga'];?>" ><br>
 		<td><input type="submit" class="btn btn-success" value="simpan">
</form>